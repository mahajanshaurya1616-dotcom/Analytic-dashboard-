// Cleaning layer: coerce types, normalise text, drop bad rows, de-duplicate.

const toNumber = (v) => {
  if (v === null || v === undefined || v === "") return null;
  const n = Number(String(v).replace(/[^0-9.\-]/g, ""));
  return Number.isFinite(n) ? n : null;
};

const toDate = (v) => {
  if (!v) return null;
  const d = new Date(v);
  return Number.isNaN(d.getTime()) ? null : d.toISOString().slice(0, 10);
};

const titleCase = (s) =>
  String(s || "")
    .trim()
    .toLowerCase()
    .replace(/\b\w/g, (c) => c.toUpperCase());

function finish(kept, total) {
  return { rows: kept, report: { received: total, kept: kept.length, dropped: total - kept.length } };
}

export function cleanSales(raw) {
  const seen = new Set();
  const kept = [];
  for (const r of raw) {
    const date = toDate(r.date);
    const revenue = toNumber(r.revenue);
    if (!r.order_id || !date || revenue === null || revenue < 0) continue;
    if (seen.has(r.order_id)) continue; // duplicate
    seen.add(r.order_id);
    kept.push({
      id: r.order_id,
      date,
      region: titleCase(r.region) || "Unknown",
      product: String(r.product || "Unknown").trim(),
      units: toNumber(r.units) ?? 1, // fill missing units
      revenue,
    });
  }
  return finish(kept, raw.length);
}

export function cleanMarketing(raw) {
  const kept = [];
  for (const r of raw) {
    const date = toDate(r.date);
    const spend = toNumber(r.spend);
    if (!date || spend === null) continue;
    kept.push({
      date,
      channel: titleCase(r.channel) || "Other",
      spend,
      impressions: toNumber(r.impressions) ?? 0,
      clicks: toNumber(r.clicks) ?? 0,
      leads: toNumber(r.leads) ?? 0,
    });
  }
  return finish(kept, raw.length);
}

export function cleanFeedback(raw) {
  const kept = [];
  for (const r of raw) {
    const date = toDate(r.date);
    const rating = toNumber(r.rating);
    if (!date || rating === null || rating < 1 || rating > 5) continue;
    kept.push({
      id: r.id,
      date,
      region: titleCase(r.region) || "Unknown",
      product: String(r.product || "Unknown").trim(),
      rating,
      comment: String(r.comment || "").trim(),
    });
  }
  return finish(kept, raw.length);
}
