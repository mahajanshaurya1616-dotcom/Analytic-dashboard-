// Simulates three upstream REST APIs with deliberately messy data,
// so the cleaning step in clean.js has real work to do.
import { Router } from "express";

const router = Router();

function rng(seed) {
  let s = seed;
  return () => (s = (s * 1664525 + 1013904223) % 4294967296) / 4294967296;
}
const pick = (r, arr) => arr[Math.floor(r() * arr.length)];
const iso = (d) => d.toISOString().slice(0, 10);

const DAYS = 180;
const REGIONS = ["North", "South", "East", "West"];
const PRODUCTS = ["Aero Backpack", "Trail Bottle", "Summit Jacket", "Camp Stove", "Dome Tent"];
const PRICES = { "Aero Backpack": 89, "Trail Bottle": 24, "Summit Jacket": 160, "Camp Stove": 55, "Dome Tent": 210 };
const CHANNELS = ["Search", "Social", "Email", "Display"];
const COMMENTS = {
  5: ["Love it", "Exactly what I needed", "Great quality"],
  4: ["Good value", "Works well", "Solid purchase"],
  3: ["It's okay", "Average", "Does the job"],
  2: ["Arrived late", "Not as described", "Feels cheap"],
  1: ["Broke quickly", "Would not recommend", "Poor support"],
};

function dayList() {
  const out = [];
  const today = new Date();
  for (let i = DAYS - 1; i >= 0; i--) {
    const d = new Date(today);
    d.setDate(today.getDate() - i);
    out.push(d);
  }
  return out;
}

function buildSales() {
  const r = rng(11);
  const rows = [];
  dayList().forEach((d, di) => {
    const orders = 3 + Math.floor(r() * 5);
    for (let i = 0; i < orders; i++) {
      const product = pick(r, PRODUCTS);
      const units = 1 + Math.floor(r() * 4);
      const growth = 1 + di / DAYS / 2;
      const revenue = +(PRICES[product] * units * growth).toFixed(2);
      let region = pick(r, REGIONS);
      if (r() < 0.08) region = ` ${region.toLowerCase()} `; // dirty casing/spaces
      rows.push({
        order_id: `S-${iso(d)}-${i}`,
        date: iso(d),
        region,
        product,
        units: r() < 0.03 ? null : units, // missing value
        revenue: r() < 0.1 ? `$${revenue.toLocaleString("en-US")}` : revenue, // string money
      });
    }
  });
  rows.push(...rows.filter((_, i) => i % 60 === 0)); // duplicates
  return rows;
}

function buildMarketing() {
  const r = rng(23);
  const rows = [];
  dayList().forEach((d) => {
    CHANNELS.forEach((channel) => {
      const spend = +(40 + r() * 160).toFixed(2);
      const impressions = Math.floor(spend * (80 + r() * 120));
      const clicks = Math.floor(impressions * (0.01 + r() * 0.03));
      rows.push({
        date: iso(d),
        channel: r() < 0.05 ? channel.toUpperCase() : channel,
        spend: r() < 0.04 ? String(spend) : spend,
        impressions,
        clicks,
        leads: Math.floor(clicks * (0.05 + r() * 0.12)),
      });
    });
  });
  rows.push({ date: "not-a-date", channel: "Search", spend: 10, impressions: 1, clicks: 1, leads: 0 }); // invalid
  return rows;
}

function buildFeedback() {
  const r = rng(37);
  const rows = [];
  dayList().forEach((d, di) => {
    const n = 1 + Math.floor(r() * 4);
    for (let i = 0; i < n; i++) {
      const bias = di > DAYS / 2 ? 0.1 : 0;
      const rating = Math.min(5, Math.max(1, Math.round(2.5 + r() * 3 + bias * 5 - 0.4)));
      rows.push({
        id: `F-${iso(d)}-${i}`,
        date: iso(d),
        region: pick(r, REGIONS),
        product: pick(r, PRODUCTS),
        rating: r() < 0.03 ? "n/a" : rating,
        comment: pick(r, COMMENTS[rating]),
      });
    }
  });
  return rows;
}

const sales = buildSales();
const marketing = buildMarketing();
const feedback = buildFeedback();

router.get("/sales", (_req, res) => res.json({ data: sales }));
router.get("/marketing", (_req, res) => res.json({ data: marketing }));
router.get("/feedback", (_req, res) => res.json({ data: feedback }));

export default router;
