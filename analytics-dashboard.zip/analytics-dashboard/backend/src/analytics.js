// Turns cleaned rows into the exact shapes the dashboard charts need.

const sum = (arr, f) => arr.reduce((t, x) => t + f(x), 0);
const round = (n, d = 2) => +Number(n).toFixed(d);

function groupBy(rows, keyFn) {
  const map = new Map();
  for (const r of rows) {
    const k = keyFn(r);
    if (!map.has(k)) map.set(k, []);
    map.get(k).push(r);
  }
  return map;
}

export const listRegions = (sales) => [...new Set(sales.map((s) => s.region))].sort();

export function buildDashboard({ sales, marketing, feedback }, { from, to, region }) {
  const inRange = (r) => (!from || r.date >= from) && (!to || r.date <= to);
  const inRegion = (r) => !region || region === "All" || r.region === region;

  const s = sales.filter((r) => inRange(r) && inRegion(r));
  const m = marketing.filter(inRange); // marketing is not split by region
  const f = feedback.filter((r) => inRange(r) && inRegion(r));

  const revenue = sum(s, (r) => r.revenue);
  const spend = sum(m, (r) => r.spend);
  const leads = sum(m, (r) => r.leads);

  const kpis = {
    revenue: round(revenue),
    orders: s.length,
    avgOrderValue: s.length ? round(revenue / s.length) : 0,
    marketingSpend: round(spend),
    roas: spend ? round(revenue / spend) : 0, // return on ad spend
    costPerLead: leads ? round(spend / leads) : 0,
    avgRating: f.length ? round(sum(f, (r) => r.rating) / f.length) : 0,
    reviews: f.length,
  };

  // Monthly revenue vs spend
  const months = new Set([...s.map((r) => r.date.slice(0, 7)), ...m.map((r) => r.date.slice(0, 7))]);
  const salesByMonth = groupBy(s, (r) => r.date.slice(0, 7));
  const mktByMonth = groupBy(m, (r) => r.date.slice(0, 7));
  const trend = [...months].sort().map((month) => ({
    month,
    revenue: round(sum(salesByMonth.get(month) || [], (r) => r.revenue)),
    spend: round(sum(mktByMonth.get(month) || [], (r) => r.spend)),
  }));

  const byRegion = [...groupBy(s, (r) => r.region)]
    .map(([name, rows]) => ({ name, revenue: round(sum(rows, (r) => r.revenue)), orders: rows.length }))
    .sort((a, b) => b.revenue - a.revenue);

  const byChannel = [...groupBy(m, (r) => r.channel)]
    .map(([name, rows]) => {
      const sp = sum(rows, (r) => r.spend);
      const ld = sum(rows, (r) => r.leads);
      return { name, spend: round(sp), leads: ld, costPerLead: ld ? round(sp / ld) : 0 };
    })
    .sort((a, b) => b.spend - a.spend);

  const topProducts = [...groupBy(s, (r) => r.product)]
    .map(([name, rows]) => ({
      name,
      revenue: round(sum(rows, (r) => r.revenue)),
      units: sum(rows, (r) => r.units),
    }))
    .sort((a, b) => b.revenue - a.revenue);

  const sentiment = [
    { name: "Positive", value: f.filter((r) => r.rating >= 4).length },
    { name: "Neutral", value: f.filter((r) => r.rating === 3).length },
    { name: "Negative", value: f.filter((r) => r.rating <= 2).length },
  ];

  const ratingDistribution = [1, 2, 3, 4, 5].map((star) => ({
    star: `${star}★`,
    count: f.filter((r) => r.rating === star).length,
  }));

  const recentFeedback = [...f].sort((a, b) => b.date.localeCompare(a.date)).slice(0, 6);

  return { kpis, trend, byRegion, byChannel, topProducts, sentiment, ratingDistribution, recentFeedback };
}
