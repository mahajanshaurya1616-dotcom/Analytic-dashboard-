// Pulls raw data from the three upstream REST APIs, cleans it, and caches it briefly.
import axios from "axios";
import { cleanSales, cleanMarketing, cleanFeedback } from "./clean.js";

const urls = () => {
  const port = process.env.PORT || 4000;
  return {
    sales: process.env.SALES_API_URL || `http://localhost:${port}/mock-sources/sales`,
    marketing: process.env.MARKETING_API_URL || `http://localhost:${port}/mock-sources/marketing`,
    feedback: process.env.FEEDBACK_API_URL || `http://localhost:${port}/mock-sources/feedback`,
  };
};

let cache = null;
let cachedAt = 0;

async function fetchJson(url) {
  const { data } = await axios.get(url, { timeout: 8000 });
  return Array.isArray(data) ? data : data.data ?? [];
}

export async function loadAllSources() {
  const ttl = Number(process.env.CACHE_TTL_SECONDS || 60) * 1000;
  if (cache && Date.now() - cachedAt < ttl) return cache;

  const u = urls();
  const [rawSales, rawMarketing, rawFeedback] = await Promise.all([
    fetchJson(u.sales),
    fetchJson(u.marketing),
    fetchJson(u.feedback),
  ]);

  const sales = cleanSales(rawSales);
  const marketing = cleanMarketing(rawMarketing);
  const feedback = cleanFeedback(rawFeedback);

  cache = {
    sales: sales.rows,
    marketing: marketing.rows,
    feedback: feedback.rows,
    quality: { sales: sales.report, marketing: marketing.report, feedback: feedback.report },
  };
  cachedAt = Date.now();
  return cache;
}
