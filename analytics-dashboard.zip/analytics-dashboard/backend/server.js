import "dotenv/config";
import express from "express";
import cors from "cors";
import mockSources from "./src/mockSources.js";
import { loadAllSources } from "./src/connectors.js";
import { buildDashboard, listRegions } from "./src/analytics.js";

const app = express();
const PORT = process.env.PORT || 4000;

app.use(cors());
app.use(express.json());

// Simulated upstream APIs (replace with real services via .env)
app.use("/mock-sources", mockSources);

app.get("/api/health", (_req, res) => res.json({ status: "ok", time: new Date().toISOString() }));

// GET /api/dashboard?from=YYYY-MM-DD&to=YYYY-MM-DD&region=North
app.get("/api/dashboard", async (req, res) => {
  try {
    const { from, to, region } = req.query;
    const data = await loadAllSources();
    res.json({
      generatedAt: new Date().toISOString(),
      regions: listRegions(data.sales),
      ...buildDashboard(data, { from, to, region }),
      quality: data.quality,
    });
  } catch (err) {
    console.error(err.message);
    res.status(502).json({ error: "Could not load data from upstream sources.", detail: err.message });
  }
});

app.listen(PORT, () => console.log(`API running on http://localhost:${PORT}`));
