import axios from "axios";

// Empty baseURL = same origin (Vite proxies /api in dev).
// For production, set VITE_API_URL=https://your-api.example.com
const client = axios.create({
  baseURL: import.meta.env.VITE_API_URL || "",
  timeout: 15000,
});

export async function fetchDashboard({ from, to, region }) {
  const params = { from, to };
  if (region && region !== "All") params.region = region;
  const { data } = await client.get("/api/dashboard", { params });
  return data;
}
