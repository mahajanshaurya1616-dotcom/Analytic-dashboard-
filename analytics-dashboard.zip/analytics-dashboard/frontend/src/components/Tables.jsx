import { money, number } from "../format.js";

export function ProductsTable({ rows }) {
  const max = Math.max(...rows.map((r) => r.revenue), 1);
  return (
    <table className="w-full text-sm">
      <thead>
        <tr className="border-b border-line text-left text-slate-500">
          <th className="pb-2 font-medium">Product</th>
          <th className="pb-2 text-right font-medium">Units</th>
          <th className="pb-2 text-right font-medium">Revenue</th>
        </tr>
      </thead>
      <tbody>
        {rows.map((r) => (
          <tr key={r.name} className="border-b border-line last:border-0">
            <td className="py-2">
              <div className="font-medium">{r.name}</div>
              <div className="mt-1 h-1.5 rounded bg-teal-soft">
                <div className="h-1.5 rounded bg-teal" style={{ width: `${(r.revenue / max) * 100}%` }} />
              </div>
            </td>
            <td className="py-2 text-right tabular-nums">{number(r.units)}</td>
            <td className="py-2 text-right tabular-nums">{money(r.revenue)}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

export function FeedbackList({ rows }) {
  if (!rows.length) return <p className="text-sm text-slate-500">No reviews in this range. Try a wider date range.</p>;
  return (
    <ul className="divide-y divide-line text-sm">
      {rows.map((r) => (
        <li key={r.id} className="flex items-start justify-between gap-4 py-2">
          <div>
            <p className="font-medium">{r.comment || "No comment"}</p>
            <p className="text-slate-500">{r.product}, {r.region}, {r.date}</p>
          </div>
          <span className={`shrink-0 rounded px-2 py-0.5 font-semibold ${r.rating >= 4 ? "bg-teal-soft text-teal" : r.rating === 3 ? "bg-slate-100 text-slate-600" : "bg-red-50 text-coral"}`}>
            {r.rating} / 5
          </span>
        </li>
      ))}
    </ul>
  );
}
