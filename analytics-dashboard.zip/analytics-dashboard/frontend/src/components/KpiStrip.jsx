import { money, number } from "../format.js";

export default function KpiStrip({ kpis }) {
  const items = [
    { label: "Revenue", value: money(kpis.revenue), sub: `${number(kpis.orders)} orders, ${money(kpis.avgOrderValue)} average` },
    { label: "Marketing spend", value: money(kpis.marketingSpend), sub: `${money(kpis.costPerLead)} per lead` },
    { label: "Return on ad spend", value: `${kpis.roas}x`, sub: "Revenue divided by spend" },
    { label: "Customer rating", value: `${kpis.avgRating} / 5`, sub: `${number(kpis.reviews)} reviews` },
  ];
  return (
    <div className="grid grid-cols-2 divide-line rounded-md border border-line bg-white lg:grid-cols-4 lg:divide-x">
      {items.map((k, i) => (
        <div key={k.label} className={`p-5 ${i > 1 ? "border-t border-line lg:border-t-0" : ""} ${i % 2 === 1 ? "border-l border-line lg:border-l-0" : ""}`}>
          <p className="text-sm text-slate-500">{k.label}</p>
          <p className="mt-1 text-3xl font-semibold tracking-tight">{k.value}</p>
          <p className="mt-1 text-sm text-slate-500">{k.sub}</p>
        </div>
      ))}
    </div>
  );
}
