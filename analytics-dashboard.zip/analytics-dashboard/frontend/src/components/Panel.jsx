export default function Panel({ title, note, children, className = "" }) {
  return (
    <section className={`rounded-md border border-line bg-white p-5 ${className}`}>
      <header className="mb-4">
        <h2 className="text-base font-semibold">{title}</h2>
        {note && <p className="mt-0.5 text-sm text-slate-500">{note}</p>}
      </header>
      {children}
    </section>
  );
}
