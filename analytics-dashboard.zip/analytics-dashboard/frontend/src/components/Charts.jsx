import {
  ResponsiveContainer, ComposedChart, Bar, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend,
  BarChart, Cell, PieChart, Pie,
} from "recharts";
import { compactMoney, money, monthLabel, number } from "../format.js";

const COLORS = { teal: "#0B7A75", amber: "#E0A100", coral: "#C8423B", ink: "#0E1B2C", mute: "#9AA7B5" };
const axis = { stroke: "#64748B", fontSize: 12, tickLine: false };

export function TrendChart({ data }) {
  return (
    <ResponsiveContainer width="100%" height={300}>
      <ComposedChart data={data} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
        <CartesianGrid stroke="#E5EAF0" vertical={false} />
        <XAxis dataKey="month" tickFormatter={monthLabel} {...axis} />
        <YAxis tickFormatter={compactMoney} width={56} {...axis} axisLine={false} />
        <Tooltip formatter={(v, n) => [money(v), n]} labelFormatter={monthLabel} />
        <Legend />
        <Bar dataKey="revenue" name="Revenue" fill={COLORS.teal} radius={[3, 3, 0, 0]} />
        <Line dataKey="spend" name="Marketing spend" stroke={COLORS.amber} strokeWidth={3} dot={{ r: 3 }} />
      </ComposedChart>
    </ResponsiveContainer>
  );
}

// Clicking a bar selects that region as the dashboard filter.
export function RegionChart({ data, activeRegion, onSelect }) {
  return (
    <ResponsiveContainer width="100%" height={260}>
      <BarChart data={data} layout="vertical" margin={{ top: 0, right: 16, left: 8, bottom: 0 }}>
        <CartesianGrid stroke="#E5EAF0" horizontal={false} />
        <XAxis type="number" tickFormatter={compactMoney} {...axis} />
        <YAxis type="category" dataKey="name" width={56} {...axis} />
        <Tooltip formatter={(v) => money(v)} cursor={{ fill: "#EEF1F4" }} />
        <Bar dataKey="revenue" name="Revenue" radius={[0, 3, 3, 0]} onClick={(d) => onSelect(d.name)} cursor="pointer">
          {data.map((d) => (
            <Cell key={d.name} fill={activeRegion === "All" || activeRegion === d.name ? COLORS.teal : COLORS.mute} />
          ))}
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  );
}

export function ChannelChart({ data }) {
  return (
    <ResponsiveContainer width="100%" height={260}>
      <ComposedChart data={data} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
        <CartesianGrid stroke="#E5EAF0" vertical={false} />
        <XAxis dataKey="name" {...axis} />
        <YAxis yAxisId="l" tickFormatter={compactMoney} width={56} {...axis} axisLine={false} />
        <YAxis yAxisId="r" orientation="right" width={44} {...axis} axisLine={false} />
        <Tooltip formatter={(v, n) => [n === "Spend" ? money(v) : number(v), n]} />
        <Legend />
        <Bar yAxisId="l" dataKey="spend" name="Spend" fill={COLORS.amber} radius={[3, 3, 0, 0]} />
        <Line yAxisId="r" dataKey="leads" name="Leads" stroke={COLORS.ink} strokeWidth={2} dot={{ r: 3 }} />
      </ComposedChart>
    </ResponsiveContainer>
  );
}

const SENTIMENT_COLORS = { Positive: COLORS.teal, Neutral: COLORS.mute, Negative: COLORS.coral };

export function SentimentChart({ data }) {
  const total = data.reduce((t, d) => t + d.value, 0);
  return (
    <ResponsiveContainer width="100%" height={260}>
      <PieChart>
        <Pie data={data} dataKey="value" nameKey="name" innerRadius={60} outerRadius={95} paddingAngle={2}
          label={({ name, value }) => `${name} ${total ? Math.round((value / total) * 100) : 0}%`}>
          {data.map((d) => <Cell key={d.name} fill={SENTIMENT_COLORS[d.name]} />)}
        </Pie>
        <Tooltip formatter={(v, n) => [number(v), n]} />
      </PieChart>
    </ResponsiveContainer>
  );
}
