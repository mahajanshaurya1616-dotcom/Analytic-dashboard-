import { useEffect, useMemo, useState } from "react";
import { fetchDashboard } from "./api.js";
import { isoDate } from "./format.js";
import Panel from "./components/Panel.jsx";
import KpiStrip from "./components/KpiStrip.jsx";
import { TrendChart, RegionChart, ChannelChart, SentimentChart } from "./components/Charts.jsx";
import { ProductsTable, FeedbackList } from "./components/Tables.jsx";

const RANGES = [
  { days: 30, label: "Last 30 days" },
  { days: 90, label: "Last 90 days" },
  { days: 180, label: "Last 180 days" },
];

export default function App() {
  const [days, setDays] = useState(90);
  const [region, setRegion] = useState("All");
  const [data, setData] = useState(null);
  const [regions, setRegions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [reloadKey, setReloadKey] = useState(0);

  const { from, to } = useMemo(() => {
    const end = new Date();
    const start = new Date();
    start.setDate(end.getDate() - days + 1);
    return { from: isoDate(start), to: isoDate(end) };
  }, [days]);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError(null);
    fetchDashboard({ from, to, region })
      .then((d) => {
        if (cancelled) return;
        setData(d);
        setRegions(d.regions);
      })
      .catch((e) => !cancelled && setError(e.response?.data?.error || "Could not reach the API. Is the backend running on port 4000?"))
      .finally(() => !cancelled && setLoading(false));
    return () => { cancelled = true; };
  }, [from, to, region, reloadKey]);

  return (
    <div className="mx-auto max-w-6xl px-4 py-8 sm:px-6">
      <header className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Trailhead Analytics</h1>
          <p className="mt-1 text-slate-600">Sales, marketing spend and customer feedback in one view.</p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <select aria-label="Date range" value={days} onChange={(e) => setDays(Number(e.target.value))}
            className="rounded-md border border-line bg-white px-3 py-2 text-sm">
            {RANGES.map((r) => <option key={r.days} value={r.days}>{r.label}</option>)}
          </select>
          <select aria-label="Region" value={region} onChange={(e) => setRegion(e.target.value)}
            className="rounded-md border border-line bg-white px-3 py-2 text-sm">
            <option value="All">All regions</option>
            {regions.map((r) => <option key={r} value={r}>{r}</option>)}
          </select>
          <button onClick={() => setReloadKey((k) => k + 1)}
            className="rounded-md bg-ink px-4 py-2 text-sm font-medium text-white hover:bg-slate-800">
            Refresh data
          </button>
        </div>
      </header>

      {error && (
        <div role="alert" className="mb-6 rounded-md border border-coral bg-red-50 p-4 text-sm text-coral">
          {error}
        </div>
      )}

      {!data && loading && <p className="text-slate-500">Loading dashboard…</p>}

      {data && (
        <main className={`space-y-6 transition-opacity ${loading ? "opacity-60" : "opacity-100"}`}>
          <KpiStrip kpis={data.kpis} />

          <Panel title="Revenue and marketing spend by month" note="Bars show revenue. The line shows what was spent on marketing.">
            <TrendChart data={data.trend} />
          </Panel>

          <div className="grid gap-6 lg:grid-cols-2">
            <Panel title="Revenue by region" note={region === "All" ? "Select a bar to filter the whole dashboard." : `Filtered to ${region}. Select it again to clear.`}>
              <RegionChart data={data.byRegion} activeRegion={region}
                onSelect={(name) => setRegion((r) => (r === name ? "All" : name))} />
            </Panel>
            <Panel title="Spend and leads by channel" note="Marketing data is not split by region.">
              <ChannelChart data={data.byChannel} />
            </Panel>
            <Panel title="Customer sentiment" note="4–5 stars positive, 3 neutral, 1–2 negative.">
              <SentimentChart data={data.sentiment} />
            </Panel>
            <Panel title="Top products by revenue">
              <ProductsTable rows={data.topProducts} />
            </Panel>
          </div>

          <Panel title="Latest customer feedback">
            <FeedbackList rows={data.recentFeedback} />
          </Panel>

          <footer className="text-sm text-slate-500">
            Data cleaned before display:{" "}
            {Object.entries(data.quality).map(([k, q]) => `${k} ${q.kept}/${q.received} rows kept`).join(", ")}.
            Updated {new Date(data.generatedAt).toLocaleTimeString()}.
          </footer>
        </main>
      )}
    </div>
  );
}
