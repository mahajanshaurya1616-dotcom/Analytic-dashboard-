/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        paper: "#EEF1F4",
        ink: "#0E1B2C",
        teal: { DEFAULT: "#0B7A75", soft: "#D5ECEA" },
        amber: { DEFAULT: "#E0A100" },
        coral: { DEFAULT: "#C8423B" },
        line: "#D3DAE2",
      },
      fontFamily: {
        sans: ['"IBM Plex Sans"', "system-ui", "sans-serif"],
      },
    },
  },
  plugins: [],
};
